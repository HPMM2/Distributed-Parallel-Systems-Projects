package Ej;

import oshi.SystemInfo;
import oshi.hardware.*;
import oshi.software.os.OperatingSystem;

import java.io.*;
import java.net.Socket;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Client2 {
    private static final int UPDATE_INTERVAL = 5000; // 5 seg
    private static final String SERVER_IP = "25.51.170.2";
    private static final int SERVER_PORT = 8080;  

    //COLORES
    private static final String RESET = "\033[0m";  // Restablecer el color
    private static final String RED = "\033[31m";  //Rojo
    private static final String GREEN = "\033[32m";  //Verde
    private static final String YELLOW = "\033[33m";  //Amarillo
    private static final String BLUE = "\033[34m";  //Azul
    
    public static void main(String[] args) {


        try (Scanner scanner = new Scanner(System.in)) {
            //ESTATICO
            String serverIp = SERVER_IP;
            int port = SERVER_PORT;

            //ID
            String clientId = getUserId();

            Socket socket = new Socket(serverIp, port);
            ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());

            //ACTUALIZACIONES
            Thread updateThread = new Thread(() -> {
                try {
                    while (!Thread.interrupted()) {
                        Map<String, Object> specs = getSystemSpecs(clientId);
                        oos.writeObject(specs);
                        oos.reset(); // Limpiar cache
                        Thread.sleep(UPDATE_INTERVAL);
                    }
                } catch (Exception e) {
                    System.out.println(RED + "Conexi�n perdida con el servidor.");
                }
            });

            updateThread.start();

            //ESPERAR ENTER PARA DESCONECTAR
            System.out.println(RED + "\nPresiona ENTER para desconectarte");
            scanner.nextLine();
            updateThread.interrupt();
            socket.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static String getUserId() {
        //Obtener el nombre del usuario actual del sistema
        return System.getProperty("user.name");
    }

    private static Map<String, Object> getSystemSpecs(String clientId) {
        SystemInfo si = new SystemInfo();
        HardwareAbstractionLayer hal = si.getHardware();
        CentralProcessor processor = hal.getProcessor();
        GlobalMemory memory = hal.getMemory();
        List<HWDiskStore> diskStores = hal.getDiskStores();
        List<NetworkIF> networks = hal.getNetworkIFs();
        OperatingSystem os = si.getOperatingSystem();

        long[] prevTicks = processor.getSystemCpuLoadTicks();
        try { Thread.sleep(1000); } catch (InterruptedException e) { }
        double cpuFree = 100.0 - (processor.getSystemCpuLoadBetweenTicks(prevTicks) * 100);

        double freeMemory = memory.getAvailable() / (1024.0 * 1024 * 1024);

        double bandwidthFree = 100.0;
        if (!networks.isEmpty()) {
            NetworkIF net = networks.get(0);
            net.updateAttributes();
            long totalBytes = net.getBytesRecv() + net.getBytesSent();
            bandwidthFree = 100.0 - (totalBytes % 100);
        }

        File rootDisk = new File("/");
        double diskFree = rootDisk.getUsableSpace() / (1024.0 * 1024 * 1024);

        Map<String, Object> specs = new HashMap<>();
        specs.put("ID", clientId);
        specs.put("Modelo del Procesador", processor.getProcessorIdentifier().getName());
        specs.put("Velocidad del Procesador (GHz)", processor.getProcessorIdentifier().getVendorFreq() / 1e9);
        specs.put("Nucleos", processor.getLogicalProcessorCount());
        specs.put("Capacidad del Disco Duro (GB)", diskStores.get(0).getSize() / (1024 * 1024 * 1024));
        specs.put("Version del Sistema Operativo", os.toString());
        specs.put("CPU Libre", String.format("%.2f", cpuFree));
        specs.put("Memoria Libre", String.format("%.2f", freeMemory));
        specs.put("Ancho de Banda Libre", String.format("%.2f", bandwidthFree));
        specs.put("Disco Libre", String.format("%.2f", diskFree));

        System.out.println(GREEN + "\n----- �Datos Actualizandose! -----" + RESET);
        System.out.println("ID: " + specs.get("ID"));
        System.out.println(BLUE + "Modelo del Procesador: " + specs.get("Modelo del Procesador"));
        System.out.println("Velocidad del Procesador: " + specs.get("Velocidad del Procesador (GHz)") + " GHz");  
        System.out.println("Nucleos: " + specs.get("Nucleos"));     
        System.out.println("Capacidad del Disco Duro: " + specs.get("Capacidad del Disco Duro (GB)") + " GB");          
        System.out.println("Version del Sistema Operativo: " + specs.get("Version del Sistema Operativo"));          
        System.out.println(YELLOW + "CPU Libre: " + specs.get("CPU Libre") + "%");
        System.out.println("Memoria Libre: " + specs.get("Memoria Libre") + " GB");
        System.out.println("Ancho de Banda Libre: " + specs.get("Ancho de Banda Libre") + "%");
        System.out.println("Disco Libre: " + specs.get("Disco Libre") + " GB");


        return specs;
     }
              
}