package sockets;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class Servidor {
    public static void main(String[] args) throws Exception {
        ObjectInputStream ois = null;
        ObjectOutputStream oos = null;

        Socket s = null;
        ServerSocket ss = new ServerSocket(5433);

        
        Scanner scanner = new Scanner(System.in);
        System.out.print("Introduce el n�mero de hilos (particiones): ");
        int numHilos = scanner.nextInt();

        System.out.println("Esperando conexiones...");

        while (true) {
            try {
                s = ss.accept();

                System.out.println("Se conectaron desde la IP: " + s.getInetAddress());
                ois = new ObjectInputStream(s.getInputStream());
                oos = new ObjectOutputStream(s.getOutputStream());

                
                List<Integer> numeros = (List<Integer>) ois.readObject();

                
                double promedio = calcularPromedio(numeros, numHilos);

                
                oos.writeObject(promedio);
                System.out.println("Promedio enviado: " + promedio);

            } catch (Exception ex) {
                ex.printStackTrace();
            } finally {
                if (oos != null) oos.close();
                if (ois != null) ois.close();
                if (s != null) s.close();
                System.out.println("Conexi�n cerrada!");
            }
        }
    }

    
    private static double calcularPromedio(List<Integer> numeros, int numHilos) throws InterruptedException {
        int size = numeros.size();
        int chunkSize = size / numHilos;
        int remainder = size % numHilos; // Para manejar los residuos al dividir
        
        List<ThreadPromedio> hilos = new ArrayList<>();
        int inicio = 0;
        
        
        for (int i = 0; i < numHilos; i++) {
            int fin = inicio + chunkSize + (i < remainder ? 1 : 0); // Asignar el residuo a las primeras particiones
            List<Integer> sublista = numeros.subList(inicio, fin);
            ThreadPromedio hilo = new ThreadPromedio(sublista);
            hilos.add(hilo);
            hilo.start();
            inicio = fin;
        }

        
        for (ThreadPromedio hilo : hilos) {
            hilo.join();
        }

        
        double sumaTotal = 0;
        for (ThreadPromedio hilo : hilos) {
            sumaTotal += hilo.getSuma();
        }

        return sumaTotal / size; // Calcular el promedio total
    }
}

// Clase que extiende Thread para calcular la suma de una partici�n
class ThreadPromedio extends Thread {
    private List<Integer> numeros;
    private double suma = 0;

    public ThreadPromedio(List<Integer> numeros) {
        this.numeros = numeros;
    }

    @Override
    public void run() {
        for (int numero : numeros) {
            suma += numero;
        }
    }

    public double getSuma() {
        return suma;
    }
}
