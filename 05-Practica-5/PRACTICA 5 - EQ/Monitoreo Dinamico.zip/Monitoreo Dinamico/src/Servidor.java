import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;

public class Servidor {
    public static void main(String[] args) {
        List<PrintWriter> clientesConectados = new ArrayList<>();

        try (ServerSocket serverSocket = new ServerSocket(12345)) {
            System.out.println("El servidor está escuchando en el puerto 12345...");

            while (true) {
                Socket socketCliente = serverSocket.accept();
                System.out.println("Cliente conectado desde: " + socketCliente.getInetAddress());

                // Agregar el PrintWriter del cliente a la lista
                PrintWriter out = new PrintWriter(socketCliente.getOutputStream(), true);
                clientesConectados.add(out);

                // Crear un hilo para manejar las comunicaciones con el cliente
                Thread clientThread = new Thread(new ClienteHandler(socketCliente, out, clientesConectados));
                clientThread.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

class ClienteHandler implements Runnable {
    private Socket socketCliente;
    private PrintWriter out;
    private List<PrintWriter> clientesConectados;

    public ClienteHandler(Socket socketCliente, PrintWriter out, List<PrintWriter> clientesConectados) {
        this.socketCliente = socketCliente;
        this.out = out;
        this.clientesConectados = clientesConectados;
    }

    @Override
    public void run() {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(socketCliente.getInputStream()));
            while (true) {
                // Leer características del cliente
                String caracteristicasCliente = in.readLine();

                // Procesar y almacenar las características
                // Puedes mostrar las características en una tabla o en el formato que desees

                // Enviar un mensaje de confirmación al cliente
                out.println("Características recibidas y registradas.");

                // Enviar las características a todos los clientes conectados
                for (PrintWriter cliente : clientesConectados) {
                    if (cliente != out) {
                        cliente.println(caracteristicasCliente);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}