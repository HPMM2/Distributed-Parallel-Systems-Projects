import oshi.SystemInfo;
import oshi.hardware.CentralProcessor;
import oshi.software.os.OperatingSystem;
import java.io.*;
import java.net.*;

public class Cliente {
    public static void main(String[] args) {
        try (Socket socket = new Socket("dirección_ip_del_servidor", 12345)) {
            SystemInfo systemInfo = new SystemInfo();
            CentralProcessor procesador = systemInfo.getHardware().getProcessor();
            OperatingSystem os = systemInfo.getOperatingSystem();
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

            while (true) {
                // Extraer características de manera dinámica
                String caracteristicasCliente = "Características del cliente:\n" +
                        "Modelo del procesador: " + procesador.getProcessorIdentifier().getName() + "\n" +
                        "Velocidad del procesador: " + procesador.getProcessorIdentifier().getVendorFreq() + " Hz\n" +
                        "Número de núcleos: " + procesador.getLogicalProcessorCount() + "\n" +
                        "Capacidad del disco duro: " + os.getFileSystem().getMaxUsableSpace("/") + " bytes\n" +
                        "Versión del sistema operativo: " + os.getVersion();

                // Enviar las características del cliente al servidor
                out.println(caracteristicasCliente);

                // Esperar un tiempo antes de volver a extraer características
                Thread.sleep(5000);  // 5 segundos
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}
