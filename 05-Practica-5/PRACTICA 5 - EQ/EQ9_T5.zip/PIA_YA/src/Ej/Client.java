package Ej;

import oshi.SystemInfo;
import oshi.hardware.*;
import oshi.software.os.OperatingSystem;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.*;
import java.net.Socket;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Client {
    private static final int UPDATE_INTERVAL = 5000; // 5 segundos
    private static final String SERVER_IP = "25.47.153.25"; // Cambia esto a la IP del servidor
    private static final int SERVER_PORT = 5355; // Cambia esto al puerto del servidor

    public static void main(String[] args) throws InterruptedException {
        try {
            String clientId = getHostName();

            // Conectar al servidor
            try (Socket socket = new Socket(SERVER_IP, SERVER_PORT);
                 ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream())) {

                // Crear y iniciar el hilo de actualizaci�n
                Thread updateThread = createUpdateThread(oos, clientId);
                updateThread.start();

                System.out.println("Sigues conectado al servidor");
                System.out.println("\nPresiona ENTER para desconectarte");
                System.in.read(); // Esperar entrada del usuario

                // Interrumpir el hilo y esperar su finalizaci�n
                updateThread.interrupt();
                try {
                    updateThread.join(); // Esperar a que el hilo termine
                } catch (InterruptedException e) {
                    System.out.println("El hilo fue interrumpido mientras esperaba su finalizaci�n.");
                    Thread.currentThread().interrupt(); // Mantener estado de interrupci�n
                }

            } catch (IOException e) {
                System.err.println("Error al conectar o enviar datos al servidor: " + e.getMessage());
            }

        } catch (IOException e) {
            System.err.println("Error al obtener el nombre del host: " + e.getMessage());
        }
    }

    private static String getHostName() throws IOException {
        return java.net.InetAddress.getLocalHost().getHostName();
    }

    private static Thread createUpdateThread(ObjectOutputStream oos, String clientId) throws InterruptedException {
        return new Thread(() -> {
            try {
                while (!Thread.currentThread().isInterrupted()) {
                    Map<String, Object> specs = getSystemSpecs(clientId);
                    oos.writeObject(specs);
                    oos.reset(); // Limpiar cache del stream

                    showSpecsInTable(specs); // Mostrar especificaciones en una tabla
                    sleepSafely(UPDATE_INTERVAL); // Esperar el intervalo de actualizaci�n
                }
            } catch (IOException e) {
                System.out.println("Error al enviar datos al servidor: " + e.getMessage());
            }
        });
    }

    private static Map<String, Object> getSystemSpecs(String clientId) {
        SystemInfo si = new SystemInfo();
        HardwareAbstractionLayer hal = si.getHardware();
        CentralProcessor processor = hal.getProcessor();
        GlobalMemory memory = hal.getMemory();
        List<HWDiskStore> diskStores = hal.getDiskStores();
        List<NetworkIF> networks = hal.getNetworkIFs();
        OperatingSystem os = si.getOperatingSystem();

        long[] prevTicks = processor.getSystemCpuLoadTicks();
        sleepSafely(1000); // Esperar un segundo

        double cpuFree = 100.0 - (processor.getSystemCpuLoadBetweenTicks(prevTicks) * 100);
        double freeMemory = memory.getAvailable() / (1024.0 * 1024 * 1024);
        double bandwidthFree = calculateBandwidthFree(networks);
        double diskFree = calculateDiskFree(diskStores);

        Map<String, Object> specs = new HashMap<>();
        specs.put("ID", clientId);
        specs.put("Modelo del Procesador", processor.getProcessorIdentifier().getName());
        specs.put("Velocidad del Procesador (GHz)", processor.getProcessorIdentifier().getVendorFreq() / 1e9);
        specs.put("N�cleos", processor.getLogicalProcessorCount());
        specs.put("Capacidad del Disco Duro (GB)", diskStores.isEmpty() ? 0 : diskStores.get(0).getSize() / (1024 * 1024 * 1024));
        specs.put("Versi�n del Sistema Operativo", os.toString());
        specs.put("CPU Libre", String.format("%.2f", cpuFree));
        specs.put("Memoria Libre", String.format("%.2f", freeMemory));
        specs.put("Ancho de Banda Libre", String.format("%.2f", bandwidthFree));
        specs.put("Disco Libre", String.format("%.2f", diskFree));

        return specs;
    }

    private static double calculateBandwidthFree(List<NetworkIF> networks) {
        if (!networks.isEmpty()) {
            NetworkIF net = networks.get(0);
            net.updateAttributes(); // Actualizar atributos de la red
            long totalBytes = net.getBytesRecv() + net.getBytesSent();
            return 100.0 - (totalBytes % 100); // Calcular el ancho de banda libre
        }
        return 100.0; // Si no hay redes disponibles
    }

    private static double calculateDiskFree(List<HWDiskStore> diskStores) {
        if (!diskStores.isEmpty()) {
            HWDiskStore diskStore = diskStores.get(0);
            long totalDiskSpace = diskStore.getSize();
            long usedDiskSpace = diskStore.getReadBytes() + diskStore.getWriteBytes();
            return (totalDiskSpace - usedDiskSpace) / (1024.0 * 1024 * 1024); // Calcular espacio libre en disco
        }
        return 0; // No hay discos disponibles
    }

    private static void sleepSafely(long milliseconds) {
        try {
            Thread.sleep(milliseconds); // Dormir el hilo
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt(); // Mantener estado de interrupci�n
        }
    }

    private static void showSpecsInTable(Map<String, Object> specs) {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Caracter�stica");
        model.addColumn("Valor");

        for (Map.Entry<String, Object> entry : specs.entrySet()) {
            model.addRow(new Object[]{entry.getKey(), entry.getValue()}); // Agregar fila por cada especificaci�n
        }

        JTable table = new JTable(model);
        table.setFillsViewportHeight(true);
        JScrollPane scrollPane = new JScrollPane(table);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.add(scrollPane);

        JDialog dialog = new JDialog();
        dialog.setTitle("Especificaciones del Sistema");
        dialog.setModal(true);
        dialog.setContentPane(panel);
        dialog.pack();
        dialog.setLocationRelativeTo(null);
        dialog.setVisible(true); // Mostrar el di�logo
    }
}
