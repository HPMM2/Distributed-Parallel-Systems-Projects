package Ej;

import oshi.SystemInfo;
import oshi.hardware.CentralProcessor;
import oshi.hardware.GlobalMemory;
import oshi.hardware.HardwareAbstractionLayer;
import oshi.hardware.HWDiskStore;
import oshi.hardware.NetworkIF;
import oshi.software.os.OperatingSystem;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.List;
import java.io.File;



public class Server {
    private static final int INTERVALO_ACTUALIZACION = 5000; // 
    private static final int PUERTO_ESTATICO = 5355; // Puerto est�tico
    private static Map<String, ClienteHandler> clientesConectados = new ConcurrentHashMap<>();
    private static DefaultTableModel tablaModelo;
    private static JTable tabla;

    public static void main(String[] args) {
        String[] nombresColumnas = {
            "Nombre", "Cliente/Servidor", "Procesador", "Velocidad (GHz)", 
            "N�cleos", "Disco Duro Total (GB)", "SO", "CPU Libre (%)", 
            "Memoria Libre (GB)", "Ancho Banda Libre (%)", "Disco Libre (GB)", "Estado"
        };
        
        tablaModelo = new DefaultTableModel(nombresColumnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tabla = new JTable(tablaModelo);
        
        // Configurar el frame
        JFrame ventana = new JFrame("Servidor");
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.add(new JScrollPane(tabla));
        ventana.setSize(1200, 400);
        ventana.setVisible(true);

        // Configurar el servidor
        try (ServerSocket serverSocket = new ServerSocket(PUERTO_ESTATICO)) { // Usar puerto est�tico
            System.out.println("Servidor iniciado en el puerto: " + PUERTO_ESTATICO);

            // Agregar datos del servidor
            agregarDatosDelServidor();

            // Hilo para actualizar datos del servidor y ordenar filas
            ScheduledExecutorService programador = Executors.newScheduledThreadPool(1);
            programador.scheduleAtFixedRate(() -> {
                actualizarDatosDelServidor();
                actualizarDatosDeClientes();
                ordenarTablaPorCpuLibre();
            }, 0, INTERVALO_ACTUALIZACION, TimeUnit.MILLISECONDS);

            // Aceptar conexiones de clientes
            while (true) {
                Socket socketCliente = serverSocket.accept();
                ClienteHandler handler = new ClienteHandler(socketCliente);
                new Thread(handler).start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void agregarDatosDelServidor() {
        SystemInfo sistemaInfo = new SystemInfo();
        HardwareAbstractionLayer hal = sistemaInfo.getHardware();
        CentralProcessor procesador = hal.getProcessor();
        OperatingSystem sistemaOperativo = sistemaInfo.getOperatingSystem();
        List<HWDiskStore> discos = hal.getDiskStores();
        
        String modeloProcesador = procesador.getProcessorIdentifier().getName();
        double velocidadProcesador = procesador.getProcessorIdentifier().getVendorFreq() / 1e9;
        int numeroNucleos = procesador.getLogicalProcessorCount();
        long tamanioDisco = discos.get(0).getSize() / (1024 * 1024 * 1024);
        
        tablaModelo.addRow(new Object[]{
            "SERVIDOR",
            "Servidor",
            modeloProcesador,
            velocidadProcesador,
            numeroNucleos,
            tamanioDisco,
            sistemaOperativo.toString(),
            0.0, // CPU Libre
            0.0, // Memoria Libre
            0.0, // Ancho de banda
            0.0, // Disco libre
            "CONECTADO"
        });
    }

    private static void actualizarDatosDelServidor() {
        SystemInfo sistemaInfo = new SystemInfo();
        HardwareAbstractionLayer hal = sistemaInfo.getHardware();
        CentralProcessor procesador = hal.getProcessor();
        GlobalMemory memoria = hal.getMemory();
        List<HWDiskStore> discos = hal.getDiskStores();
        
        // Calcular CPU libre
        long[] ticksPrevios = procesador.getSystemCpuLoadTicks();
        try { Thread.sleep(1000); } catch (InterruptedException e) { }
        double cpuLibre = 100.0 - (procesador.getSystemCpuLoadBetweenTicks(ticksPrevios) * 100);

        // Calcular memoria libre
        double memoriaLibre = memoria.getAvailable() / (1024.0 * 1024 * 1024);

        // Calcular ancho de banda libre (aproximado basado en la utilizaci�n de red)
        final double anchoBandaLibre;
        List<NetworkIF> redes = hal.getNetworkIFs();
        if (!redes.isEmpty()) {
            NetworkIF red = redes.get(0);
            red.updateAttributes();
            long bytesTotales = red.getBytesRecv() + red.getBytesSent();
            anchoBandaLibre = 100.0 - (bytesTotales % 100); // Simplificado para ejemplo
        } else {
            anchoBandaLibre = 100.0;
        }

        // Calcular espacio libre en disco
        File discoRaiz = new File("/");
        double discoLibre = discoRaiz.getUsableSpace() / (1024.0 * 1024 * 1024); // Convertimos a GB

        // Actualizar fila del servidor
        SwingUtilities.invokeLater(() -> {
            tablaModelo.setValueAt(String.format("%.2f", cpuLibre), 0, 7);
            tablaModelo.setValueAt(String.format("%.2f", memoriaLibre), 0, 8);
            tablaModelo.setValueAt(String.format("%.2f", anchoBandaLibre), 0, 9);
            tablaModelo.setValueAt(String.format("%.2f", discoLibre), 0, 10);
        });
    }

    private static void actualizarDatosDeClientes() {
        // Crear una lista temporal de clientes a remover
        List<String> clientesAEliminar = new ArrayList<>();
        
        // Verificar clientes desconectados
        clientesConectados.forEach((id, handler) -> {
            if (!handler.isConnected()) {
                actualizarEstadoCliente(id, "DESCONECTADO");
                clientesAEliminar.add(id);
            }
        });
        
        // Remover clientes desconectados
        clientesAEliminar.forEach(clientesConectados::remove);
        
        // Actualizar la tabla solo para clientes conectados
        for (int i = 0; i < tablaModelo.getRowCount(); i++) {
            String idCliente = (String) tablaModelo.getValueAt(i, 0);
            String estado = (String) tablaModelo.getValueAt(i, 11);
            
            // Si es el servidor, continuar con el siguiente
            if (idCliente.equals("SERVIDOR")) {
                continue;
            }
            
            // Si el cliente est� desconectado, mantener los valores pero en gris
            if (estado.equals("DESCONECTADO")) {
                tabla.setRowSelectionInterval(i, i);
                tabla.setSelectionBackground(Color.LIGHT_GRAY);
            }
        }
    }

    private static void actualizarEstadoCliente(String idCliente, String estado) {
        for (int i = 0; i < tablaModelo.getRowCount(); i++) {
            if (tablaModelo.getValueAt(i, 0).equals(idCliente)) {
                tablaModelo.setValueAt(estado, i, 11);
                
                if (estado.equals("DESCONECTADO")) {
                    // Limpiar todos los campos excepto ID y tipo de cliente
                    tablaModelo.setValueAt("", i, 2);  // Modelo Procesador
                    tablaModelo.setValueAt(0.0, i, 3);  // Velocidad
                    tablaModelo.setValueAt(0, i, 4);    // N�cleos
                    tablaModelo.setValueAt(0.0, i, 5);  // Disco Duro Total
                    tablaModelo.setValueAt("", i, 6);   // SO
                    tablaModelo.setValueAt(0.0, i, 7);  // CPU Libre
                    tablaModelo.setValueAt(0.0, i, 8);  // Memoria Libre
                    tablaModelo.setValueAt(0.0, i, 9);  // Ancho Banda Libre
                    tablaModelo.setValueAt(0.0, i, 10); // Disco Libre
                    
                    // Cambiar color de fondo a gris
                    tabla.setRowSelectionInterval(i, i);
                    tabla.setSelectionBackground(Color.LIGHT_GRAY);
                } else {
                    tabla.clearSelection();
                    tabla.setSelectionBackground(tabla.getBackground());
                }
                break;
            }
        }
        ordenarTablaPorCpuLibre();
    }

    private static void ordenarTablaPorCpuLibre() {
        TableRowSorter<DefaultTableModel> ordenado = new TableRowSorter<>(tablaModelo);
        
        // Configurar comparador personalizado
        ordenado.setComparator(7, Comparator.comparingDouble(value -> {
            if (value instanceof String) {
                return Double.parseDouble((String) value);
            }
            return 0.0;
        }).reversed());
        
        tabla.setRowSorter(ordenado);
    }

    private static class ClienteHandler implements Runnable {
        private Socket socket;
        private boolean conectado;

        public ClienteHandler(Socket socket) {
            this.socket = socket;
            this.conectado = true;
            String idCliente = "CLIENTE" + clientesConectados.size();
            clientesConectados.put(idCliente, this);
        }

        @Override
        public void run() {
            try (BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                 PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {
                out.println("Conectado como " + socket.getInetAddress() + ":" + socket.getPort());

                String mensaje;
                while ((mensaje = in.readLine()) != null) {
                    System.out.println("Mensaje recibido de " + socket.getInetAddress() + ": " + mensaje);
                    // Aqu� puedes implementar la l�gica de manejo del mensaje del cliente
                }
            } catch (IOException e) {
                System.err.println("Error en la conexi�n del cliente: " + e.getMessage());
            } finally {
                conectado = false;
                try {
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        public boolean isConnected() {
            return conectado;
        }
    }
}
