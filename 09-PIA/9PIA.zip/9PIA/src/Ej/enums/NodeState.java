package Ej.enums;

public enum NodeState {
    TRANSICION, ESTABLE
}
