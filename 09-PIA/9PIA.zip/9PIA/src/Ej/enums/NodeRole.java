package Ej.enums;

public enum NodeRole {
    SERVIDOR, CLIENTE    
}
