// package Ej.Nodes;

// import oshi.SystemInfo;
// import oshi.hardware.*;
// import oshi.software.os.OperatingSystem;

// import java.io.*;
// import java.net.DatagramPacket;
// import java.net.DatagramSocket;
// import java.net.InetAddress;
// import java.net.Socket;
// import java.util.HashMap;
// import java.util.List;
// import java.util.Map;
// import java.util.Scanner;

// public class Client {
//     private static final int UPDATE_INTERVAL = 5000; // 5 seg
//     private static final int SERVER_PORT = 3001;

//     private static final String MESSAGE_CODE_SEARCH = "searching-for-server";

//     // COLORES
//     private static final String RESET = "\033[0m"; // Restablecer el color
//     private static final String RED = "\033[31m"; // Rojo
//     private static final String GREEN = "\033[32m"; // Verde
//     private static final String YELLOW = "\033[33m"; // Amarillo
//     private static final String BLUE = "\033[34m"; // Azul

//     public static void main(String[] args) {
//         Scanner scanner = new Scanner(System.in);
        
//         try {
//             String serverIp = args[0];

//             // Conectar al servidor
//             int port = SERVER_PORT;
//             String clientId = getUserId();
//             Socket socket = new Socket(serverIp, port);
//             ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());

//             // Enviar actualizaciones periódicas
//             Thread updateThread = new Thread(() -> {
//                 try {
//                     while (!Thread.interrupted()) {
//                         Map<String, Object> specs = getSystemSpecs(clientId);
//                         oos.writeObject(specs);
//                         oos.reset(); // Limpiar cache
//                         Thread.sleep(UPDATE_INTERVAL);
//                     }
//                 } catch (Exception e) {
//                     System.out.println(RED + "Conexión perdida con el servidor." + RESET);
//                 }
//             });

//             updateThread.start();

//             // Esperar ENTER para desconectarse
//             System.out.println(RED + "\nPresiona ENTER para desconectarte." + RESET);
//             scanner.nextLine();
//             updateThread.interrupt();
//             socket.close();

//         } catch (Exception e) {
//             System.out.println(RED + "Ocurrió un error inesperado: " + e.getMessage() + RESET);
//             e.printStackTrace();
//         } finally {
//             scanner.close();
//         }
//     }

//     public static String getServerIp() {
//         byte[] buffer = new byte[1024];
//         DatagramSocket socketUDP = null;

//         try {
//             // Crear el socket UDP
//             socketUDP = new DatagramSocket();
//             // Enviar solicitud de búsqueda al servidor
//             InetAddress serverAddress = InetAddress.getByName("25.255.255.255");
//             String messageCode = MESSAGE_CODE_SEARCH;
//             buffer = messageCode.getBytes();

//             System.out.println("Server Address: " + serverAddress);
//             DatagramPacket serverSearchRequest = new DatagramPacket(buffer, buffer.length, serverAddress, SERVER_PORT);
//             System.out.println("Enviando datagrama de búsqueda del servidor...");
//             socketUDP.send(serverSearchRequest);

//             // Esperar respuesta del servidor
//             DatagramPacket responseDatagram = new DatagramPacket(buffer, buffer.length);

//             try {
//                 socketUDP.setSoTimeout(5000); // Esperar 5 segundos
//                 socketUDP.receive(responseDatagram);
//                 System.out.println("Respuesta recibida del servidor.");

//                 // Procesar la respuesta
//                 String response = new String(responseDatagram.getData()).trim();
//                 String[] parts = response.split("-server");
//                 // La IP estará en la primera parte
//                 String ip = parts[0];
//                 if (!ip.matches("\\d+\\.\\d+\\.\\d+\\.\\d+")) {
//                     throw new IllegalArgumentException("Respuesta inválida: " + response);
//                 }

//                 System.out.println("Dirección IP del servidor: " + ip);
//                 return ip;
//             } catch (IOException e) {
//                 System.out.println(e);
//                 System.out.println(RED + "No se encontró un servidor disponible en la red." + RESET);
//                 System.out.println(YELLOW + "TODO: Implementar funcionalidad para que este cliente actúe como servidor." + RESET);
//                 return null;
//             }

//         // Cerrar el socket UDP ya que no será necesario
//         } catch (IOException e) {
//               System.out.println("Ocurrió la excepción IOE");
//         }
//         catch (Exception e) {
//              System.out.println("Ocurrió una excepción innesperada");
//         } finally {
//                if (socketUDP != null && !socketUDP.isClosed()) {
//                    socketUDP.close();
//                }
//         }
//         return null;
//     } 

//     private static String getUserId() {
//         return System.getProperty("user.name");
//     }

//     private static Map<String, Object> getSystemSpecs(String clientId) {
//         SystemInfo si = new SystemInfo();
//         HardwareAbstractionLayer hal = si.getHardware();
//         CentralProcessor processor = hal.getProcessor();
//         GlobalMemory memory = hal.getMemory();
//         List<HWDiskStore> diskStores = hal.getDiskStores();
//         List<NetworkIF> networks = hal.getNetworkIFs();
//         OperatingSystem os = si.getOperatingSystem();

//         long[] prevTicks = processor.getSystemCpuLoadTicks();
//         try { Thread.sleep(1000); } catch (InterruptedException e) { }
//         double cpuFree = 100.0 - (processor.getSystemCpuLoadBetweenTicks(prevTicks) * 100);

//         double freeMemory = memory.getAvailable() / (1024.0 * 1024 * 1024);

//         double bandwidthFree = 100.0;
//         if (!networks.isEmpty()) {
//             NetworkIF net = networks.get(0);
//             net.updateAttributes();
//             long totalBytes = net.getBytesRecv() + net.getBytesSent();
//             bandwidthFree = 100.0 - (totalBytes % 100);
//         }

//         File rootDisk = new File("/");
//         double diskFree = rootDisk.getUsableSpace() / (1024.0 * 1024 * 1024);

//         Map<String, Object> specs = new HashMap<>();
//         specs.put("ID", clientId);
//         specs.put("Modelo del Procesador", processor.getProcessorIdentifier().getName());
//         specs.put("Velocidad del Procesador (GHz)", processor.getProcessorIdentifier().getVendorFreq() / 1e9);
//         specs.put("Nucleos", processor.getLogicalProcessorCount());
//         specs.put("Capacidad del Disco Duro (GB)", diskStores.get(0).getSize() / (1024 * 1024 * 1024));
//         specs.put("Version del Sistema Operativo", os.toString());
//         specs.put("CPU Libre", String.format("%.2f", cpuFree));
//         specs.put("Memoria Libre", String.format("%.2f", freeMemory));
//         specs.put("Ancho de Banda Libre", String.format("%.2f", bandwidthFree));
//         specs.put("Disco Libre", String.format("%.2f", diskFree));

//         System.out.println(GREEN + "\n----- Datos Actualizados -----" + RESET);
//         System.out.println("ID: " + specs.get("ID"));
//         System.out.println(BLUE + "Modelo del Procesador: " + specs.get("Modelo del Procesador"));
//         System.out.println("Velocidad del Procesador: " + specs.get("Velocidad del Procesador (GHz)") + " GHz");
//         System.out.println("Nucleos: " + specs.get("Nucleos"));
//         System.out.println("Capacidad del Disco Duro: " + specs.get("Capacidad del Disco Duro (GB)") + " GB");
//         System.out.println("Versión del Sistema Operativo: " + specs.get("Version del Sistema Operativo"));
//         System.out.println(YELLOW + "CPU Libre: " + specs.get("CPU Libre") + "%");
//         System.out.println("Memoria Libre: " + specs.get("Memoria Libre") + " GB");
//         System.out.println("Ancho de Banda Libre: " + specs.get("Ancho de Banda Libre") + "%");
//         System.out.println("Disco Libre: " + specs.get("Disco Libre") + " GB");

//         return specs;
//     }
// }
