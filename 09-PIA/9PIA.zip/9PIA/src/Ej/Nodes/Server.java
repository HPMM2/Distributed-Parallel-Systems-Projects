// package Ej.Nodes;

// import javax.swing.*;
// import javax.swing.table.DefaultTableModel;
// import javax.swing.table.TableRowSorter;

// import Ej.utils.IpUtils;

// import java.awt.*;
// import java.io.*;
// import java.net.*;
// import java.util.*;
// import java.util.concurrent.*;
// import java.util.List;

// import oshi.SystemInfo;
// import oshi.hardware.CentralProcessor;
// import oshi.hardware.GlobalMemory;
// import oshi.hardware.HardwareAbstractionLayer;
// import oshi.hardware.HWDiskStore;
// import oshi.hardware.NetworkIF;
// import oshi.software.os.OperatingSystem;

// public class Server {
//     private static final int UPDATE_INTERVAL = 5000; // 5 segundos
//     private static Map<String, ClientHandler> connectedClients = new ConcurrentHashMap<>();
//     private static DefaultTableModel model;
//     private static JTable table;
//     private static final int SERVER_PORT = 3001;  // Puerto estático

//     private static final String MESSAGE_CODE_SEARCH = "searching-for-server";

//     //COLORES
//     private static final String RESET = "\033[0m";  //Restablecer el color
//     private static final String RED = "\033[31m";  //R
//     private static final String GREEN = "\033[32m";  //V
//     private static final String YELLOW = "\033[33m";  //A
//     private static final String BLUE = "\033[34m";  //AZ
    
    
//     public static void main(String[] args) {
//         String[] columnNames = {
//             "ID", "Cliente/Servidor", "Modelo Procesador", "Velocidad (GHz)", 
//             "Nucleos", "Disco Duro Total (GB)", "SO", "CPU Libre (%)", 
//             "Memoria Libre (GB)", "Ancho Banda Libre (%)", "Disco Libre (GB)", "Estado"
//         };
        
//         model = new DefaultTableModel(columnNames, 0) {
//             @Override
//             public boolean isCellEditable(int row, int column) {
//                 return false;
//             }
//         };
//         table = new JTable(model);
        
//         // Configurar el frame
//         JFrame frame = new JFrame("Servidor");
//         frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//         frame.add(new JScrollPane(table));
//         frame.setSize(1200, 400);
//         frame.setVisible(true);

//         System.out.println(GREEN + "Esperando conexiones..." + RESET);

//         // Se escucha por peticiones de clientes para saber el serverIp (broadcast)
//         Thread ipRequestHandlerThread = new Thread(() -> handleServerIpRequests());
//         ipRequestHandlerThread.start();
        
//         // Configurar el servidor con un puerto est�tico
//         ServerSocket serverSocket = null;
//         try {
//             serverSocket = new ServerSocket(SERVER_PORT);
//             // Agregar datos del servidor
//             addServerData();

//             // Hilo para actualizar datos del servidor y ordenar filas
//             ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
//             scheduler.scheduleAtFixedRate(() -> {
//                 updateServerData();
//                 updateClientsData();
//                 sortTableByCpuFree();
//             }, 0, UPDATE_INTERVAL, TimeUnit.MILLISECONDS);

//             // Aceptar conexiones de clientes
//             while (true) {
//                 Socket clientSocket = serverSocket.accept();
//                 ClientHandler handler = new ClientHandler(clientSocket);
//                 new Thread(handler).start();
//             }
//         } catch (Exception e) {
//             e.printStackTrace();
//         }
//     }

//     private static void handleServerIpRequests() {
//         byte[] buffer = new byte[1024];
//         DatagramSocket socketUDP = null;
    
//         try {
//             System.out.println("Iniciado el servidor UDP");
//             // Creación del socket
//             socketUDP = new DatagramSocket(SERVER_PORT);
    
//             // Siempre atenderá peticiones
//             while (true) {
//                 try {
//                     // Preparar el datagrama para recibir la solicitud del cliente
//                     DatagramPacket requestFromClient = new DatagramPacket(buffer, buffer.length);
    
//                     // Recibir el datagrama
//                     socketUDP.receive(requestFromClient);
//                     System.out.println("Recibo la información del cliente");
    
//                     // Convertir el mensaje recibido y mostrarlo
//                     String message = new String(requestFromClient.getData(), 0, requestFromClient.getLength()).trim();
//                     System.out.println("Mensaje del cliente: " + message);
    
//                     // Validar si el mensaje coincide con el código esperado
//                     if (MESSAGE_CODE_SEARCH.equals(message)) {
//                         String serverIp = IpUtils.getOwnIp(); // Obtener la IP del servidor
//                         System.out.println("IP del servidor: " + serverIp);
    
//                         // Obtener el puerto y la dirección del cliente
//                         int clientPort = requestFromClient.getPort();
//                         InetAddress clientAddress = requestFromClient.getAddress();
    
//                         // Preparar la respuesta con la IP del servidor
//                         byte[] responseBuffer = serverIp.getBytes();
//                         DatagramPacket responseForClient = new DatagramPacket(responseBuffer, responseBuffer.length, clientAddress, clientPort);
    
//                         // Enviar la respuesta
//                         System.out.println("Se envió la IP del servidor al cliente: " + clientAddress);
//                         socketUDP.send(responseForClient);
//                     }
//                 } catch (Exception innerException) {
//                     // Manejo de excepciones dentro del ciclo para continuar con otras solicitudes
//                     System.err.println("Error procesando solicitud del cliente: " + innerException.getMessage());
//                     innerException.printStackTrace();
//                 }
//             }
//         } catch (Exception e) {
//             // Manejo de excepciones al iniciar el servidor
//             System.err.println("Error iniciando el servidor UDP: " + e.getMessage());
//             e.printStackTrace();
//         } finally {
//             // Asegurarse de cerrar el socket al terminar
//             if (socketUDP != null && !socketUDP.isClosed()) {
//                 socketUDP.close();
//                 System.out.println("Socket UDP cerrado.");
//             }
//         }
//     }
    

//     private static void addServerData() {
//         SystemInfo si = new SystemInfo();
//         HardwareAbstractionLayer hal = si.getHardware();
//         CentralProcessor processor = hal.getProcessor();  
//         OperatingSystem os = si.getOperatingSystem();
//         List<HWDiskStore> diskStores = hal.getDiskStores();
        
//         String processorModel = processor.getProcessorIdentifier().getName();
//         double processorSpeed = processor.getProcessorIdentifier().getVendorFreq() / 1e9;
//         int cores = processor.getLogicalProcessorCount();
//         long diskSize = diskStores.get(0).getSize() / (1024 * 1024 * 1024);

        
//         model.addRow(new Object[] {
//             System.getProperty("user.name"),
//             "SERVIDOR",
//             processorModel,
//             processorSpeed,
//             cores,
//             diskSize,
//             os.toString(),
//             0.0, // CPU Libre
//             0.0, // Memoria Libre
//             0.0, // Ancho de banda
//             0.0, // Disco libre
//             "CONECTADO"
//         });
//     }

//     private static double updateServerData() {
//         SystemInfo si = new SystemInfo();
//         HardwareAbstractionLayer hal = si.getHardware();
//         CentralProcessor processor = hal.getProcessor();
//         GlobalMemory memory = hal.getMemory();
//         List<HWDiskStore> diskStores = hal.getDiskStores();
        
//         // Calcular CPU libre
//         long[] prevTicks = processor.getSystemCpuLoadTicks();
//         try { Thread.sleep(1000); } catch (InterruptedException e) { }
//         double cpuFree = 100.0 - (processor.getSystemCpuLoadBetweenTicks(prevTicks) * 100);

        
        
//         // Calcular memoria libre
//         double freeMemory = memory.getAvailable() / (1024.0 * 1024 * 1024);

//         // Calcular ancho de banda libre (aproximado basado en la utilización de red)
//         final double bandwidthFree;
//         List<NetworkIF> networks = hal.getNetworkIFs();
//         if (!networks.isEmpty()) {
//             NetworkIF net = networks.get(0);
//             net.updateAttributes();
//             long totalBytes = net.getBytesRecv() + net.getBytesSent();
//             bandwidthFree = 100.0 - (totalBytes % 100); // Simplificado para ejemplo
//         } else {
//             bandwidthFree = 100.0;
//         }

//         // Calcular espacio libre en disco
//         File rootDisk = new File("/");
//         double diskFree = rootDisk.getUsableSpace() / (1024.0 * 1024 * 1024); // Convertimos a GB

//         // Actualizar fila del servidor
//         SwingUtilities.invokeLater(() -> {
//             model.setValueAt(String.format("%.2f", cpuFree), 0, 7);
//             model.setValueAt(String.format("%.2f", freeMemory), 0, 8);
//             model.setValueAt(String.format("%.2f", bandwidthFree), 0, 9);
//             model.setValueAt(String.format("%.2f", diskFree), 0, 10);
//         });
//         return cpuFree;
//     }

//     private static void updateClientsData() {
//         // Crear una lista temporal de clientes a remover
//         List<String> clientsToRemove = new ArrayList<>();
        
//         // Verificar clientes desconectados
//         connectedClients.forEach((id, handler) -> {
//             if (!handler.isConnected()) {
//                 updateClientStatus(id, "DESCONECTADO");
//                 clientsToRemove.add(id);
//             }
//         });
        
//         // Remover clientes desconectados
//         clientsToRemove.forEach(connectedClients::remove);
        
//         // Actualizar la tabla solo para clientes conectados
//         for (int i = 0; i < model.getRowCount(); i++) {
//             String clientId = (String) model.getValueAt(i, 0);
//             String status = (String) model.getValueAt(i, 11);
            
//             // Si es el servidor, continuar con el siguiente
//             if (clientId.equals("SERVIDOR")) {
//                 continue;
//             }
            
//             // Si el cliente está desconectado, mantener los valores pero en gris
//             if (status.equals("DESCONECTADO")) {
//                 table.setRowSelectionInterval(i, i);
//                 table.setSelectionBackground(Color.LIGHT_GRAY);
//             }
//         }
//     }

//     private static void updateClientStatus(String clientId, String status) {
//         for (int i = 0; i < model.getRowCount(); i++) {
//             if (model.getValueAt(i, 0).equals(clientId)) {
//                 model.setValueAt(status, i, 11);
                
//                 if (status.equals("DESCONECTADO")) {
//                     // Limpiar todos los campos excepto ID y tipo de cliente
//                     model.setValueAt("", i, 2);  // Modelo Procesador
//                     model.setValueAt(0.0, i, 3);  // Velocidad
//                     model.setValueAt(0, i, 4);    // Núcleos
//                     model.setValueAt(0.0, i, 5);  // Disco Duro Total
//                     model.setValueAt("", i, 6);   // SO
//                     model.setValueAt(0.0, i, 7);  // CPU Libre
//                     model.setValueAt(0.0, i, 8);  // Memoria Libre
//                     model.setValueAt(0.0, i, 9);  // Ancho Banda Libre
//                     model.setValueAt(0.0, i, 10); // Disco Libre
                    
//                     // Cambiar color de fondo a gris
//                     table.setRowSelectionInterval(i, i);
//                     table.setSelectionBackground(Color.LIGHT_GRAY);
//                 } else {
//                     table.clearSelection();
//                     table.setSelectionBackground(table.getBackground());
//                 }
//                 break;
//             }
//         }
//         sortTableByCpuFree();
//     }

//     private static void sortTableByCpuFree() {
//         TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
        
//         // Configurar comparador personalizado
//         sorter.setComparator(7, (value1, value2) -> {
//             int row1 = -1, row2 = -1;
            
//             // Encontrar las filas correspondientes a los valores
//             for (int i = 0; i < model.getRowCount(); i++) {
//                 if (model.getValueAt(i, 7).equals(value1)) row1 = i;
//                 if (model.getValueAt(i, 7).equals(value2)) row2 = i;
//             }
            
//             // Obtener estados de conexi�n
//             String status1 = model.getValueAt(row1, 11).toString();
//             String status2 = model.getValueAt(row2, 11).toString();
            
//             // Si uno est� desconectado y el otro no, el desconectado va al final
//             if (status1.equals("DESCONECTADO") && !status2.equals("DESCONECTADO")) return 1;
//             if (!status1.equals("DESCONECTADO") && status2.equals("DESCONECTADO")) return -1;
            
//             // Si ambos est�n desconectados, mantener el orden actual
//             if (status1.equals("DESCONECTADO") && status2.equals("DESCONECTADO")) {
//                 return row1 - row2;
//             }
            
//             // Asegurarse de que los valores sean v�lidos para convertir a Double
//             double cpu1 = parseDoubleSafely(value1);
//             double cpu2 = parseDoubleSafely(value2);
            
//             // Ordenar por CPU libre
//             return Double.compare(cpu2, cpu1); // Orden descendente
//         });
        
//         table.setRowSorter(sorter);

//         // Aplicar orden descendente en la columna 7 (CPU Libre)
//         List<RowSorter.SortKey> sortKeys = new ArrayList<>();
//         sortKeys.add(new RowSorter.SortKey(7, SortOrder.ASCENDING));
//         sorter.setSortKeys(sortKeys);
//         sorter.sort();
        
//         // Ahora, asignamos el tipo "Servidor" a quien tiene el CPU m�s alto
//         double maxCpuFree = -1;
//         int maxCpuRow = -1;
        
//         // Encontramos la fila con el CPU m�s alto
//         for (int i = 0; i < model.getRowCount(); i++) {
//             double cpuFree = parseDoubleSafely(model.getValueAt(i, 7));  // Valor de CPU Libre en la columna 7
//             if (cpuFree > maxCpuFree) {
//                 maxCpuFree = cpuFree;
//                 maxCpuRow = i;
//             }
//         }

//         // Asignamos "Servidor" a la fila con el CPU m�s alto y "Cliente" a las dem�s
//         for (int i = 0; i < model.getRowCount(); i++) {
//             if (i == maxCpuRow) {
//                 model.setValueAt("SERVIDOR", i, 1);  // Columna 1 es la que tiene el estado
//             } else {
//                 model.setValueAt("CLIENTE", i, 1);  // Asignamos "Cliente" a las dem�s filas
//             }
//         }
//     }

//     // M�todo seguro para convertir String a Double
//     private static double parseDoubleSafely(Object value) {
//         try {
//             return Double.parseDouble(value.toString());
//         } catch (NumberFormatException e) {
//             return 0.0; // Si el valor no es un n�mero v�lido, se devuelve 0.0
//         }
//     }



//     static class ClientHandler implements Runnable {
//         private final Socket socket;
//         private String clientId;
//         private volatile boolean connected = true;
//         private ObjectInputStream ois;

//         public ClientHandler(Socket socket) {
//             this.socket = socket;
//         }

//         @Override
//         public void run() {
//             try {
//                 ois = new ObjectInputStream(socket.getInputStream());
//                 // Esperar hasta que se reciba el ID del cliente
//                 Object receivedObject = ois.readObject();
//                 if (receivedObject instanceof Map) {
//                     Map<String, Object> clientSpecs = (Map<String, Object>) receivedObject;
//                     clientId = (String) clientSpecs.get("ID");
//                     // Agregar al mapa de clientes conectados
//                     connectedClients.put(clientId, this);
                    
//                     while (connected) {
//                         receivedObject = ois.readObject();
//                         if (receivedObject instanceof Map) {
//                             clientSpecs = (Map<String, Object>) receivedObject;
//                             handleClientData(clientSpecs);
//                         }
//                     }
//                 }
//             } catch (EOFException e) {
//                 System.out.println(RED + "Cliente desconectado: " + RESET + clientId);
//                 connected = false;
//             } catch (IOException e) {
//                 System.out.println(RED + "Error de conexion con el cliente: " + RESET + clientId);
//                 connected = false;
//             } catch (ClassNotFoundException e) {
//                 e.printStackTrace();
//             } finally {
//                 try {
//                     if (ois != null) {
//                         ois.close();
//                     }
//                     socket.close();
//                 } catch (IOException e) {
//                     e.printStackTrace();
//                 }

//                 // Actualizar el estado del cliente en el servidor
//                 if (clientId != null) {
//                     connected = false;
//                     updateClientStatus(clientId, "DESCONECTADO");
//                 }
//             }
//         }

//         private void handleClientData(final Map<String, Object> clientSpecs) {
//             SwingUtilities.invokeLater(() -> {
//                 boolean clientExists = false;
//                 String clientId = (String) clientSpecs.get("ID");

//                 for (int i = 0; i < model.getRowCount(); i++) {
//                     if (model.getValueAt(i, 0).equals(clientId)) {
//                         // Si el cliente existe pero estaba desconectado, actualizar su estado
//                         if (model.getValueAt(i, 11).equals("DESCONECTADO")) {
//                             model.setValueAt("CONECTADO", i, 11);
//                             table.clearSelection();
//                             table.setSelectionBackground(table.getBackground());
//                         }
//                         updateRowData(i, clientSpecs);
//                         clientExists = true;
//                         break;
//                     }
//                 }

//                 if (!clientExists) {
//                     addNewClient(clientSpecs);
//                 }
                
//                 // Forzar reordenamiento después de actualizar
//                 sortTableByCpuFree();
//             });
//         }

//         private void updateRowData(int row, Map<String, Object> specs) {
//             // Solo actualizar si el cliente está conectado
//             if (model.getValueAt(row, 11).equals("CONECTADO")) {
//                 model.setValueAt(specs.get("Modelo del Procesador"), row, 2);
//                 model.setValueAt(specs.get("Velocidad del Procesador (GHz)"), row, 3);
//                 model.setValueAt(specs.get("Nucleos"), row, 4);
//                 model.setValueAt(specs.get("Capacidad del Disco Duro (GB)"), row, 5);
//                 model.setValueAt(specs.get("Version del Sistema Operativo"), row, 6);
//                 model.setValueAt(specs.get("CPU Libre"), row, 7);
//                 model.setValueAt(specs.get("Memoria Libre"), row, 8);
//                 model.setValueAt(specs.get("Ancho de Banda Libre"), row, 9);
//                 model.setValueAt(specs.get("Disco Libre"), row, 10);
//             }
//         }

//         private void addNewClient(Map<String, Object> specs) {

//         	model.addRow(new Object[]{
//                 specs.get("ID"),
//                 "CLIENTE",
//                 specs.get("Modelo del Procesador"),
//                 specs.get("Velocidad del Procesador (GHz)"),
//                 specs.get("Nucleos"),
//                 specs.get("Capacidad del Disco Duro (GB)"),
//                 specs.get("Version del Sistema Operativo"),
//                 specs.get("CPU Libre"),
//                 specs.get("Memoria Libre"),
//                 specs.get("Ancho de Banda Libre"),
//                 specs.get("Disco Libre"),
//                 "CONECTADO"
//             });
//         }

//         public boolean isConnected() {
//             return connected;
//         }
//     }
// }