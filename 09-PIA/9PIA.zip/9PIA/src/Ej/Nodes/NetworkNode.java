package Ej.Nodes;

import java.awt.Color;
import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import Ej.enums.NodeRole;
import Ej.utils.IpUtils;
import Ej.utils.ThreadUtils;
import oshi.SystemInfo;
import oshi.hardware.CentralProcessor;
import oshi.hardware.GlobalMemory;
import oshi.hardware.HWDiskStore;
import oshi.hardware.HardwareAbstractionLayer;
import oshi.hardware.NetworkIF;
import oshi.software.os.OperatingSystem;

public class NetworkNode {
    // Numeric Constants
    private static final int UPDATE_INTERVAL = 5000; // 5 seg
    private static final int TRANSFER_SERVER_ROLE_INTERVAL = 15000; // 15 seg
    private static final int SERVER_PORT = 3001;

    // Socket Communication Codes
    private static final String SERVER_SEARCH_CODE = "searching-for-server";
    private static final String SERVER_LOST_CODE = "server-lost";
    private static final String SERVER_TRANSITION_CODE = "server-transition";

    // Colors
    private static final String RESET = "\033[0m"; // Restablecer el color
    private static final String RED = "\033[31m"; // Rojo
    private static final String GREEN = "\033[32m"; // Verde
    private static final String YELLOW = "\033[33m"; // Amarillo
    private static final String BLUE = "\033[34m"; // Azul

    // Starts at true because we need to define the role in the beginning
    private static Boolean needsToUpdateNodeRole = true;
    private static NodeRole newNodeRole = NodeRole.CLIENTE;

    private static Thread currentNodeRoleThread = null;

    public static void main(String[] args) {
        String serverIp = IpUtils.requestServerIpByUdp(SERVER_PORT);
        if (serverIp == null) {
            newNodeRole = NodeRole.SERVIDOR;
        }
        if (needsToUpdateNodeRole) {
            handleNodeRoleTransition(serverIp, args);
            needsToUpdateNodeRole = false;
        }
    }

    private static void handleNodeRoleTransition(String serverIp, String[] args) {
        if (newNodeRole == NodeRole.CLIENTE) {
            handleClientRole(serverIp, args);
        } else if (newNodeRole == NodeRole.SERVIDOR) {
            handleServerRole(args);
        }
    }

    private static void handleClientRole(String serverIp, String[] args) {
        if (serverIp == null) {
            System.out.println("No encontró el servidor, este host se convertirá en servidor");
            ThreadUtils.interruptCurrentThread(currentNodeRoleThread);
            currentNodeRoleThread = new Thread(() -> Server.main(args));
        } else {
            System.out.println("Conectado al servidor: " + serverIp);
            ThreadUtils.interruptCurrentThread(currentNodeRoleThread);
            Client.setServerIp(serverIp);
            currentNodeRoleThread = new Thread(() -> Client.main(args));
        }
        currentNodeRoleThread.start();
    }

    private static void handleServerRole(String[] args) {
        ThreadUtils.interruptCurrentThread(currentNodeRoleThread);
        currentNodeRoleThread = new Thread(() -> Server.main(args));
        currentNodeRoleThread.start();
    }

    class Client {
        private static String serverIp = null;

        public static void main(String[] args) {
            System.out.println(GREEN + "Cliente iniciado" + RESET);
            Scanner scanner = new Scanner(System.in);
            Thread broadcastThread = null;
            Thread updateThread = null;
            try {
                // Conectar al servidor
                int port = SERVER_PORT;
                String clientId = getUserId();
                System.out.println(YELLOW + "SERVER IP: " + serverIp);
                Socket socket = new Socket(serverIp, port);

                broadcastThread = new Thread(() -> listenToBroadcast(socket, args));
                broadcastThread.start();

                ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());

                // Enviar actualizaciones periódicas
                updateThread = new Thread(() -> {
                    try {
                        while (!Thread.interrupted() && !needsToUpdateNodeRole) {
                            Map<String, Object> specs = getSystemSpecs(clientId);
                            oos.writeObject(specs);
                            oos.reset(); // Limpiar cache
                            Thread.sleep(UPDATE_INTERVAL);
                        }
                    } catch (Exception e) {
                        System.out.println(RED + "Conexión perdida con el servidor." + RESET);
                    }
                });

                updateThread.start();

                // Esperar ENTER para desconectarse
                System.out.println(RED + "\nPresiona ENTER para desconectarte." + RESET);
                scanner.nextLine();
                socket.close();

            } catch (Exception e) {
                System.out.println(RED + "Ocurrió un error inesperado: " + e.getMessage() + RESET);
                e.printStackTrace();
            } finally {
                System.err.println(YELLOW + "Bloque de finally activado" + RESET);
                scanner.close();

                if (updateThread != null && updateThread.isAlive()) {
                    updateThread.interrupt();
                    try {
                        updateThread.join();
                    } catch (InterruptedException e) {
                        System.err.println(RED + "Error al unir el hilo de actualización: " + e.getMessage() + RESET);
                    }
                }

                if (broadcastThread != null && broadcastThread.isAlive()) {
                    broadcastThread.interrupt();
                    try {
                        broadcastThread.join();
                    } catch (InterruptedException e) {
                        System.err.println(RED + "Error al unir el hilo de broadcast: " + e.getMessage() + RESET);
                    }
                }
            }
        }

        private static void listenToBroadcast(Socket socket, String[] args) {
            byte[] buffer = new byte[1024];
            DatagramSocket socketUDP = null;

            try {
                // Crear el socket UDP para escuchar los mensajes
                socketUDP = new DatagramSocket(SERVER_PORT);

                // Crear un datagrama para recibir los mensajes
                DatagramPacket responseDatagram = new DatagramPacket(buffer, buffer.length);

                System.err.println("Escuchando el broadcast (CLIENT)");
                while (!Thread.interrupted()) {
                    try {
                        // Recibir el datagrama
                        socketUDP.receive(responseDatagram);
                        System.out.println("Broadcast recibido del servidor");

                        // Convertir los datos del datagrama en una cadena
                        String response = new String(responseDatagram.getData()).trim();

                        // Verificar si el mensaje contiene ciertos códigos y actuar en consecuencia
                        if (response.contains(SERVER_LOST_CODE) || response.contains(SERVER_TRANSITION_CODE)) {
                            socket.close(); // Cerrar el socket TCP si es necesario
                            socketUDP.close();
                            String ownId = getUserId();
                            String[] parts = response.split(" ");
                            needsToUpdateNodeRole = true;
                            if (parts[1].equals(ownId)) {
                                newNodeRole = NodeRole.SERVIDOR;
                                needsToUpdateNodeRole = false;
                                Server.main(args);
                            } else {
                                Thread.sleep(6000); // Esperar 3 segundos para que el nuevo servidor se configure
                                newNodeRole = NodeRole.CLIENTE;
                                needsToUpdateNodeRole = false;
                                Client.main(args);
                            }
                        }
                    } catch (SocketException e) {
                        if (socketUDP.isClosed()) {
                            break; // Salir del bucle si el socket se cierra
                        }
                    } catch (IOException e) {
                        System.out.println(RED + "Excepción de E/S: " + e.getMessage() + RESET);
                    } catch (InterruptedException e) {
                        System.out.println("El hilo fue interrumpido: " + e.getMessage());
                        break; // Si el hilo es interrumpido, salimos del bucle
                    } catch (Exception e) {
                        System.out.println("Ocurrió una excepción inesperada: " + e.getMessage());
                    }
                }
            } catch (IOException e) {
                System.out.println("Error al crear el socket UDP: " + e.getMessage());
            } finally {
                // Cerrar el socket UDP cuando termine el proceso
                if (socketUDP != null && !socketUDP.isClosed()) {
                    socketUDP.close();
                }
            }
        }

        public static void setServerIp(String ip) {
            serverIp = ip;
        }

        private static String getUserId() {
            return System.getProperty("user.name");
        }

        private static Map<String, Object> getSystemSpecs(String clientId) {
            SystemInfo si = new SystemInfo();
            HardwareAbstractionLayer hal = si.getHardware();
            CentralProcessor processor = hal.getProcessor();
            GlobalMemory memory = hal.getMemory();
            List<HWDiskStore> diskStores = hal.getDiskStores();
            List<NetworkIF> networks = hal.getNetworkIFs();
            OperatingSystem os = si.getOperatingSystem();

            long[] prevTicks = processor.getSystemCpuLoadTicks();
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
            }
            double cpuFree = 100.0 - (processor.getSystemCpuLoadBetweenTicks(prevTicks) * 100);

            double freeMemory = memory.getAvailable() / (1024.0 * 1024 * 1024);

            double bandwidthFree = 100.0;
            if (!networks.isEmpty()) {
                NetworkIF net = networks.get(0);
                net.updateAttributes();
                long totalBytes = net.getBytesRecv() + net.getBytesSent();
                bandwidthFree = 100.0 - (totalBytes % 100);
            }

            File rootDisk = new File("/");
            double diskFree = rootDisk.getUsableSpace() / (1024.0 * 1024 * 1024);

            Map<String, Object> specs = new HashMap<>();
            specs.put("ID", clientId);
            specs.put("Modelo del Procesador", processor.getProcessorIdentifier().getName());
            specs.put("Velocidad del Procesador (GHz)", processor.getProcessorIdentifier().getVendorFreq() / 1e9);
            specs.put("Nucleos", processor.getLogicalProcessorCount());
            specs.put("Capacidad del Disco Duro (GB)", diskStores.get(0).getSize() / (1024 * 1024 * 1024));
            specs.put("Version del Sistema Operativo", os.toString());
            specs.put("CPU Libre", String.format("%.2f", cpuFree));
            specs.put("Memoria Libre", String.format("%.2f", freeMemory));
            specs.put("Ancho de Banda Libre", String.format("%.2f", bandwidthFree));
            specs.put("Disco Libre", String.format("%.2f", diskFree));

            System.out.println(GREEN + "\n----- Datos Actualizados -----" + RESET);
            System.out.println("ID: " + specs.get("ID"));
            System.out.println(BLUE + "Modelo del Procesador: " + specs.get("Modelo del Procesador"));
            System.out.println("Velocidad del Procesador: " + specs.get("Velocidad del Procesador (GHz)") + " GHz");
            System.out.println("Nucleos: " + specs.get("Nucleos"));
            System.out.println("Capacidad del Disco Duro: " + specs.get("Capacidad del Disco Duro (GB)") + " GB");
            System.out.println("Versión del Sistema Operativo: " + specs.get("Version del Sistema Operativo"));
            System.out.println(YELLOW + "CPU Libre: " + specs.get("CPU Libre") + "%");
            System.out.println("Memoria Libre: " + specs.get("Memoria Libre") + " GB");
            System.out.println("Ancho de Banda Libre: " + specs.get("Ancho de Banda Libre") + "%");
            System.out.println("Disco Libre: " + specs.get("Disco Libre") + " GB");

            return specs;
        }
    }

    class Server {
        private static Map<String, ClientHandler> connectedClients = new ConcurrentHashMap<>();
        private static DefaultTableModel model;
        private static JTable table;

        private static ScheduledExecutorService updateDataScheduler = null;
        private static ScheduledExecutorService transferServerRoleScheduler = null;

        private static String newServerId = null;

        public static void main(String[] args) {
            System.out.println(BLUE + "Servidor iniciado" + RESET);
            String[] columnNames = {
                    "ID", "Cliente/Servidor", "Modelo Procesador", "Velocidad (GHz)",
                    "Nucleos", "Disco Duro Total (GB)", "SO", "CPU Libre (%)",
                    "Memoria Libre (GB)", "Ancho Banda Libre (%)", "Disco Libre (GB)", "Estado"
            };

            model = new DefaultTableModel(columnNames, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            table = new JTable(model);

            // Configurar el frame
            JFrame frame = new JFrame("Servidor");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.add(new JScrollPane(table));
            frame.setSize(1200, 400);
            frame.setVisible(true);

            // Se escucha por peticiones de clientes para saber el serverIp (broadcast)
            Thread ipRequestHandlerThread = new Thread(() -> handleServerIpRequests());
            ipRequestHandlerThread.start();

            try {
                final ServerSocket serverSocket = new ServerSocket(SERVER_PORT);

                // Shutdown hook
                Runtime.getRuntime().addShutdownHook(new Thread(() -> {

                    System.out.println(RED + "Programa cerrado. Realizando tareas de limpieza..." + RESET);
                    try {
                        if (serverSocket != null && !serverSocket.isClosed()) {
                            serverSocket.close();
                        }
                        transferServerRoleDueToServerLoss();
                    } catch (IOException e) {
                        System.err.println(YELLOW + "Error al cerrar el socket del servidor" + RESET);
                    }
                }));

                // Agregar datos del servidor
                addServerData();

                // Hilo para actualizar datos del servidor y ordenar filas
                updateDataScheduler = Executors.newScheduledThreadPool(1);
                updateDataScheduler.scheduleAtFixedRate(() -> {
                    if (needsToUpdateNodeRole) {
                        return;
                    }
                    updateServerData();
                    updateClientsData();
                    sortTableByCpuFree();
                }, 0, UPDATE_INTERVAL, TimeUnit.MILLISECONDS);

                transferServerRoleScheduler = Executors.newScheduledThreadPool(1);
                transferServerRoleScheduler.scheduleAtFixedRate(() -> {

                    if (needsToUpdateNodeRole) {
                        return;
                    }

                    System.out.println("ESTA VERIFICANDO SI HAY UN HOST CON MÁS CAPACIDAD");

                    if (connectedClients.isEmpty()) {
                        return;
                    }
                    sortTableByCpuFree();
                    int maxCpuRowIndex = getMaxCpuRowIndexFromModel();
                    String maxCpuNodeId = model.getValueAt(maxCpuRowIndex, 0).toString();
                    String ownId = System.getProperty("user.name");

                    if (maxCpuNodeId.equals(ownId)) {
                        return;
                    }

                    newServerId = maxCpuNodeId;
                    System.out.println(BLUE + "Nuevo servidor id (por mejor capacidad): " + newServerId + RESET);

                    // Limpieza de recursos
                    try {
                        needsToUpdateNodeRole = true;
                        if (serverSocket != null && !serverSocket.isClosed()) {
                            serverSocket.close(); // Cerramos el socket del servidor
                        }
                        for (ClientHandler handler : connectedClients.values()) {
                            try {
                                handler.socket.close(); // Cerrar el socket del cliente
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                        connectedClients.clear(); // Limpiar la lista de clientes conectados
                        SwingUtilities.invokeLater(() -> {
                            frame.dispose(); // Cierra la ventana
                        });
                        // Limpiamos recursos adicionales si es necesario
                        ipRequestHandlerThread.interrupt();
                    } catch (Exception e) {
                        System.err.println("Error desconocido al intentar cerrar el server socket");
                    }

                    IpUtils.broadcastNewServerIdDueToBetterCapacity(SERVER_PORT, newServerId);

                    Thread waitThread = new Thread(() -> {
                        waitForServerSetup(7, 5000);

                        System.out.println(GREEN + "Conviertiendose en cliente..." + RESET);

                        updateDataScheduler.shutdownNow();
                        transferServerRoleScheduler.shutdownNow();

                        needsToUpdateNodeRole = false;

                        String serverIp = IpUtils.requestServerIpByUdp(SERVER_PORT);
                        Client.setServerIp(serverIp);
                        Client.main(args);
                    });
                    waitThread.start();

                }, 15000, TRANSFER_SERVER_ROLE_INTERVAL, TimeUnit.MILLISECONDS);

                // Aceptar conexiones de clientes
                System.out.println("Esperando conexiones a hosts" + RESET);
                while (true) {
                    Socket clientSocket = serverSocket.accept();
                    ClientHandler handler = new ClientHandler(clientSocket);
                    new Thread(handler).start();
                }
            } catch (Exception e) {
                if (e.getMessage() != "Socket closed") {
                    e.printStackTrace();
                }
            } finally {
                updateDataScheduler.shutdownNow();
                transferServerRoleScheduler.shutdownNow();
            }
        }

        private static void waitForServerSetup(int retryCount, long intervalMillis) {
            int attempts = 0;
            while (attempts < retryCount) {
                try {
                    System.out.println(YELLOW + "Esperando que el nuevo servidor esté listo..." + RESET);
                    Thread.sleep(intervalMillis); // Esperar el intervalo configurado
                    return; // Salir si no hay interrupción
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt(); // Restaurar el estado de interrupción
                    System.err.println(RED + "Espera interrumpida. Reintentando..." + RESET);
                }
                attempts++;
            }
            System.err.println(RED + "Se agotaron los intentos de espera para el nuevo servidor." + RESET);
        }

        private static void handleServerIpRequests() {
            byte[] buffer = new byte[1024];
            DatagramSocket socketUDP = null;

            try {
                System.out.println("Escuchando por peticiones del serverIp");
                // Creación del socket
                socketUDP = new DatagramSocket(SERVER_PORT);

                // Siempre atenderá peticiones
                while (!needsToUpdateNodeRole) {
                    try {
                        // Preparar el datagrama para recibir la solicitud del cliente
                        DatagramPacket requestFromClient = new DatagramPacket(buffer, buffer.length);

                        // Recibir el datagrama
                        socketUDP.receive(requestFromClient);
                        // Convertir el mensaje recibido y mostrarlo
                        String message = new String(requestFromClient.getData(), 0, requestFromClient.getLength())
                                .trim();

                        // Validar si el mensaje coincide con el código esperado
                        if (SERVER_SEARCH_CODE.equals(message)) {
                            String serverIp = IpUtils.getOwnIp(); // Obtener la IP del servidor

                            // Obtener el puerto y la dirección del cliente
                            int clientPort = requestFromClient.getPort();
                            InetAddress clientAddress = requestFromClient.getAddress();

                            // Preparar la respuesta con la IP del servidor
                            byte[] responseBuffer = serverIp.getBytes();
                            DatagramPacket responseForClient = new DatagramPacket(responseBuffer, responseBuffer.length,
                                    clientAddress, clientPort);

                            // Enviar la respuesta
                            System.out.println("Se envió la IP del servidor al cliente: " + clientAddress);
                            socketUDP.send(responseForClient);
                        }
                    } catch (Exception innerException) {
                        // Manejo de excepciones dentro del ciclo para continuar con otras solicitudes
                        System.err.println("Error procesando solicitud del cliente: " + innerException.getMessage());
                        innerException.printStackTrace();
                    }
                }
            } catch (Exception e) {
                // Manejo de excepciones al iniciar el servidor
                System.err.println("Error iniciando el servidor UDP: " + e.getMessage());
                e.printStackTrace();
            } finally {
                // Asegurarse de cerrar el socket al terminar
                if (socketUDP != null && !socketUDP.isClosed()) {
                    socketUDP.close();
                }
            }
        }

        private static void addServerData() {
            SystemInfo si = new SystemInfo();
            HardwareAbstractionLayer hal = si.getHardware();
            CentralProcessor processor = hal.getProcessor();
            OperatingSystem os = si.getOperatingSystem();
            List<HWDiskStore> diskStores = hal.getDiskStores();

            String processorModel = processor.getProcessorIdentifier().getName();
            double processorSpeed = processor.getProcessorIdentifier().getVendorFreq() / 1e9;
            int cores = processor.getLogicalProcessorCount();
            long diskSize = diskStores.get(0).getSize() / (1024 * 1024 * 1024);

            model.addRow(new Object[] {
                    System.getProperty("user.name"),
                    "SERVIDOR",
                    processorModel,
                    processorSpeed,
                    cores,
                    diskSize,
                    os.toString(),
                    0.0, // CPU Libre
                    0.0, // Memoria Libre
                    0.0, // Ancho de banda
                    0.0, // Disco libre
                    "CONECTADO"
            });
        }

        private static double updateServerData() {
            SystemInfo si = new SystemInfo();
            HardwareAbstractionLayer hal = si.getHardware();
            CentralProcessor processor = hal.getProcessor();
            GlobalMemory memory = hal.getMemory();
            List<HWDiskStore> diskStores = hal.getDiskStores();

            // Calcular CPU libre
            long[] prevTicks = processor.getSystemCpuLoadTicks();
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
            }
            double cpuFree = 100.0 - (processor.getSystemCpuLoadBetweenTicks(prevTicks) * 100);

            // Calcular memoria libre
            double freeMemory = memory.getAvailable() / (1024.0 * 1024 * 1024);

            // Calcular ancho de banda libre (aproximado basado en la utilización de red)
            final double bandwidthFree;
            List<NetworkIF> networks = hal.getNetworkIFs();
            if (!networks.isEmpty()) {
                NetworkIF net = networks.get(0);
                net.updateAttributes();
                long totalBytes = net.getBytesRecv() + net.getBytesSent();
                bandwidthFree = 100.0 - (totalBytes % 100); // Simplificado para ejemplo
            } else {
                bandwidthFree = 100.0;
            }

            // Calcular espacio libre en disco
            File rootDisk = new File("/");
            double diskFree = rootDisk.getUsableSpace() / (1024.0 * 1024 * 1024); // Convertimos a GB

            // Actualizar fila del servidor
            SwingUtilities.invokeLater(() -> {
                model.setValueAt(String.format("%.2f", cpuFree), 0, 7);
                model.setValueAt(String.format("%.2f", freeMemory), 0, 8);
                model.setValueAt(String.format("%.2f", bandwidthFree), 0, 9);
                model.setValueAt(String.format("%.2f", diskFree), 0, 10);
            });
            return cpuFree;
        }

        private static void updateClientsData() {
            // Crear una lista temporal de clientes a remover
            List<String> clientsToRemove = new ArrayList<>();

            // Verificar clientes desconectados
            connectedClients.forEach((id, handler) -> {
                if (!handler.isConnected()) {
                    updateClientStatus(id, "DESCONECTADO");
                    clientsToRemove.add(id);
                }
            });

            // Remover clientes desconectados
            clientsToRemove.forEach(connectedClients::remove);

            // Actualizar la tabla solo para clientes conectados
            for (int i = 0; i < model.getRowCount(); i++) {
                String clientId = (String) model.getValueAt(i, 0);
                String status = (String) model.getValueAt(i, 11);

                // Si es el servidor, continuar con el siguiente
                if (clientId.equals("SERVIDOR")) {
                    continue;
                }

                // Si el cliente está desconectado, mantener los valores pero en gris
                if (status.equals("DESCONECTADO")) {
                    table.setRowSelectionInterval(i, i);
                    table.setSelectionBackground(Color.LIGHT_GRAY);
                }
            }
        }

        private static void updateClientStatus(String clientId, String status) {
            for (int i = 0; i < model.getRowCount(); i++) {
                if (model.getValueAt(i, 0).equals(clientId)) {
                    model.setValueAt(status, i, 11);

                    if (status.equals("DESCONECTADO")) {
                        // Limpiar todos los campos excepto ID y tipo de cliente
                        model.setValueAt("", i, 2); // Modelo Procesador
                        model.setValueAt(0.0, i, 3); // Velocidad
                        model.setValueAt(0, i, 4); // Núcleos
                        model.setValueAt(0.0, i, 5); // Disco Duro Total
                        model.setValueAt("", i, 6); // SO
                        model.setValueAt(0.0, i, 7); // CPU Libre
                        model.setValueAt(0.0, i, 8); // Memoria Libre
                        model.setValueAt(0.0, i, 9); // Ancho Banda Libre
                        model.setValueAt(0.0, i, 10); // Disco Libre

                        // Cambiar color de fondo a gris
                        table.setRowSelectionInterval(i, i);
                        table.setSelectionBackground(Color.LIGHT_GRAY);
                    } else {
                        table.clearSelection();
                        table.setSelectionBackground(table.getBackground());
                    }
                    break;
                }
            }
            sortTableByCpuFree();
        }

        private static void sortTableByCpuFree() {
            TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);

            // Configurar comparador personalizado
            sorter.setComparator(7, (value1, value2) -> {
                int row1 = -1, row2 = -1;

                // Encontrar las filas correspondientes a los valores
                for (int i = 0; i < model.getRowCount(); i++) {
                    if (model.getValueAt(i, 7).equals(value1))
                        row1 = i;
                    if (model.getValueAt(i, 7).equals(value2))
                        row2 = i;
                }

                // Obtener estados de conexión
                String status1 = model.getValueAt(row1, 11).toString();
                String status2 = model.getValueAt(row2, 11).toString();

                // Si uno está desconectado y el otro no, el desconectado va al final
                if (status1.equals("DESCONECTADO") && !status2.equals("DESCONECTADO"))
                    return 1;
                if (!status1.equals("DESCONECTADO") && status2.equals("DESCONECTADO"))
                    return -1;

                // Si ambos están desconectados, mantener el orden actual
                if (status1.equals("DESCONECTADO") && status2.equals("DESCONECTADO")) {
                    return row1 - row2;
                }

                // Asegurarse de que los valores sean válidos para convertir a Double
                double cpu1 = parseDoubleSafely(value1);
                double cpu2 = parseDoubleSafely(value2);

                // Ordenar por CPU libre
                return Double.compare(cpu2, cpu1); // Orden descendente
            });

            table.setRowSorter(sorter);

            // Aplicar orden descendente en la columna 7 (CPU Libre)
            List<RowSorter.SortKey> sortKeys = new ArrayList<>();
            sortKeys.add(new RowSorter.SortKey(7, SortOrder.ASCENDING));
            sorter.setSortKeys(sortKeys);
            sorter.sort();
        }

        private static Integer getMaxCpuRowIndexFromModel() {
            // Encontramos la fila con el CPU más alto
            double maxCpuFree = -1;
            int maxCpuRowIndex = -1;

            for (int i = 0; i < model.getRowCount(); i++) {
                double cpuFree = parseDoubleSafely(model.getValueAt(i, 7)); // Valor de CPU Libre en la columna 7
                if (cpuFree > maxCpuFree) {
                    maxCpuFree = cpuFree;
                    maxCpuRowIndex = i;
                }
            }
            return maxCpuRowIndex;
        }

        private static void transferServerRoleDueToServerLoss() {
            if (connectedClients.size() == 0) {
                return;
            }
            sortTableByCpuFree();
            int maxCpuRowIndex = getMaxCpuRowIndexFromModel();
            String maxCpuNodeId = model.getValueAt(maxCpuRowIndex, 0).toString();
            String ownId = System.getProperty("user.name");
            String _newServerId = null;
            if (maxCpuNodeId == ownId) {
                _newServerId = model.getValueAt(maxCpuRowIndex + 1, 0).toString();
            } else {
                _newServerId = maxCpuNodeId;
            }
            System.err.println(BLUE + "Nuevo servidor id (por desconexión del actual): " + _newServerId + RESET);

            // Enviar un broadcast udp con el id del nuevo servidor
            IpUtils.broadcastNewServerIdDueToServerLoss(SERVER_PORT, _newServerId);
        }

        // Método seguro para convertir String a Double
        private static double parseDoubleSafely(Object value) {
            try {
                return Double.parseDouble(value.toString());
            } catch (NumberFormatException e) {
                return 0.0; // Si el valor no es un n�mero v�lido, se devuelve 0.0
            }
        }

        static class ClientHandler implements Runnable {
            private final Socket socket;
            private String clientId;
            private volatile boolean connected = true;
            private ObjectInputStream ois;

            public ClientHandler(Socket socket) {
                this.socket = socket;
            }

            @Override
            public void run() {
                try {
                    ois = new ObjectInputStream(socket.getInputStream());
                    // Esperar hasta que se reciba el ID del cliente
                    Object receivedObject = ois.readObject();
                    if (receivedObject instanceof Map) {
                        Map<String, Object> clientSpecs = (Map<String, Object>) receivedObject;
                        clientId = (String) clientSpecs.get("ID");
                        // Agregar al mapa de clientes conectados
                        connectedClients.put(clientId, this);

                        while (connected) {
                            receivedObject = ois.readObject();
                            if (receivedObject instanceof Map) {
                                clientSpecs = (Map<String, Object>) receivedObject;
                                handleClientData(clientSpecs);
                            }
                        }
                    }
                } catch (EOFException e) {
                    System.out.println(RED + "Cliente desconectado: " + RESET + clientId);
                    connected = false;
                } catch (IOException e) {
                    System.out.println(RED + "Error de conexion con el cliente: " + RESET + clientId);
                    connected = false;
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (ois != null) {
                            ois.close();
                        }
                        socket.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    // Actualizar el estado del cliente en el servidor
                    if (clientId != null) {
                        connected = false;
                        updateClientStatus(clientId, "DESCONECTADO");
                    }
                }
            }

            private void handleClientData(final Map<String, Object> clientSpecs) {
                SwingUtilities.invokeLater(() -> {
                    boolean clientExists = false;
                    String clientId = (String) clientSpecs.get("ID");

                    for (int i = 0; i < model.getRowCount(); i++) {
                        if (model.getValueAt(i, 0).equals(clientId)) {
                            // Si el cliente existe pero estaba desconectado, actualizar su estado
                            if (model.getValueAt(i, 11).equals("DESCONECTADO")) {
                                model.setValueAt("CONECTADO", i, 11);
                                table.clearSelection();
                                table.setSelectionBackground(table.getBackground());
                            }
                            updateRowData(i, clientSpecs);
                            clientExists = true;
                            break;
                        }
                    }

                    if (!clientExists) {
                        addNewClient(clientSpecs);
                    }

                    // Forzar reordenamiento después de actualizar
                    sortTableByCpuFree();
                });
            }

            private void updateRowData(int row, Map<String, Object> specs) {
                // Solo actualizar si el cliente está conectado
                if (model.getValueAt(row, 11).equals("CONECTADO")) {
                    model.setValueAt(specs.get("Modelo del Procesador"), row, 2);
                    model.setValueAt(specs.get("Velocidad del Procesador (GHz)"), row, 3);
                    model.setValueAt(specs.get("Nucleos"), row, 4);
                    model.setValueAt(specs.get("Capacidad del Disco Duro (GB)"), row, 5);
                    model.setValueAt(specs.get("Version del Sistema Operativo"), row, 6);
                    model.setValueAt(specs.get("CPU Libre"), row, 7);
                    model.setValueAt(specs.get("Memoria Libre"), row, 8);
                    model.setValueAt(specs.get("Ancho de Banda Libre"), row, 9);
                    model.setValueAt(specs.get("Disco Libre"), row, 10);
                }
            }

            private void addNewClient(Map<String, Object> specs) {

                model.addRow(new Object[] {
                        specs.get("ID"),
                        "CLIENTE",
                        specs.get("Modelo del Procesador"),
                        specs.get("Velocidad del Procesador (GHz)"),
                        specs.get("Nucleos"),
                        specs.get("Capacidad del Disco Duro (GB)"),
                        specs.get("Version del Sistema Operativo"),
                        specs.get("CPU Libre"),
                        specs.get("Memoria Libre"),
                        specs.get("Ancho de Banda Libre"),
                        specs.get("Disco Libre"),
                        "CONECTADO"
                });
            }

            public boolean isConnected() {
                return connected;
            }
        }
    }
}
