package Ej.utils;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Enumeration;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class IpUtils {

    private static final String SERVER_SEARCH_CODE = "searching-for-server";
    private static final String SERVER_LOST_CODE = "server-lost";
    private static final String SERVER_TRANSITION_CODE = "server-transition";

    private static final String RESET = "\033[0m"; // Restablecer el color
    private static final String RED = "\033[31m"; // Rojo
    private static final String YELLOW = "\033[33m"; // Amarillo

    public static String getOwnIp() {
        try {
            // Iterar sobre todas las interfaces de red
            Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
            while (networkInterfaces.hasMoreElements()) {
                NetworkInterface networkInterface = networkInterfaces.nextElement();

                // Ignorar interfaces que están deshabilitadas o no son útiles
                if (networkInterface.isLoopback() || !networkInterface.isUp()) {
                    continue;
                }

                // Iterar sobre las direcciones de cada interfaz
                Enumeration<InetAddress> inetAddresses = networkInterface.getInetAddresses();
                while (inetAddresses.hasMoreElements()) {
                    InetAddress inetAddress = inetAddresses.nextElement();

                    // Filtrar y devolver solo direcciones IPv4
                    if (!inetAddress.isLoopbackAddress() && inetAddress.getHostAddress().indexOf(':') == -1) {
                        return inetAddress.getHostAddress(); // IP del servidor
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "25.0.0.0"; // Dirección IP por defecto si no se encuentra otra
    }

    public static String requestServerIpByUdp(Integer serverPort) {
        byte[] buffer = new byte[1024];
        DatagramSocket socketUDP = null;

        try {
            // Crear el socket UDP
            socketUDP = new DatagramSocket();
            // Enviar solicitud de búsqueda al servidor
            InetAddress broadcastAddress = InetAddress.getByName("25.255.255.255");
            String messageCode = SERVER_SEARCH_CODE;
            buffer = messageCode.getBytes();

            DatagramPacket serverSearchRequest = new DatagramPacket(buffer, buffer.length, broadcastAddress,
                    serverPort);
            System.out.println("Buscando servidor a través de UDP...");
            System.out.println("Enviando datagrama de búsqueda del servidor...");
            socketUDP.send(serverSearchRequest);

            // Esperar respuesta del servidor
            DatagramPacket responseDatagram = new DatagramPacket(buffer, buffer.length);

            try {
                socketUDP.setSoTimeout(10000); // Esperar 10 segundos
                socketUDP.receive(responseDatagram);
                System.out.println("Respuesta recibida del servidor.");

                // Procesar la respuesta
                String response = new String(responseDatagram.getData()).trim();
                System.err.println(RED + "RESPONSE: " + response + RESET);

                // Usar una expresión regular para extraer la IP
                String ipRegex = "(\\d+\\.\\d+\\.\\d+\\.\\d+)";
                Pattern pattern = Pattern.compile(ipRegex);
                Matcher matcher = pattern.matcher(response);

                if (matcher.find()) {
                    String ip = matcher.group(1);
                    System.out.println("Dirección IP del servidor: " + ip);
                    return ip;
                } else {
                    throw new IllegalArgumentException("Respuesta inválida: " + response);
                }
            } catch (IOException e) {
                System.out.println(RED + "No se encontró un servidor disponible en la red." + RESET);
                return null;
            }

        } catch (IOException e) {
            System.out.println("Ocurrió la excepción IOE");
        } catch (Exception e) {
            System.out.println("Ocurrió una excepción inesperada: " + e);
        } finally {
            if (socketUDP != null && !socketUDP.isClosed()) {
                socketUDP.close();
            }
        }
        return null;
    }

    public static void broadcastNewServerIdDueToServerLoss(Integer serverPort, String newServerId) {
        byte[] buffer = new byte[1024];
        DatagramSocket socketUDP = null;

        try {
            // Crear el socket UDP
            socketUDP = new DatagramSocket();
            // Enviar solicitud de búsqueda al servidor
            InetAddress broadcastAddress = InetAddress.getByName("25.255.255.255");
            String messageCode = SERVER_LOST_CODE + " " + newServerId;
            buffer = messageCode.getBytes();

            DatagramPacket serverSearchRequest = new DatagramPacket(buffer, buffer.length, broadcastAddress,
                    serverPort);
            System.out.println("Enviando datagrama de id del nuevo servidor...");
            socketUDP.send(serverSearchRequest);

        } catch (IOException e) {
            System.out.println("Ocurrió la excepción IOE");
        } catch (Exception e) {
            System.out.println("Ocurrió una excepción innesperada");
        } finally {
            // Cerrar el socket UDP ya que no será necesario
            if (socketUDP != null && !socketUDP.isClosed()) {
                socketUDP.close();
            }
        }
    }

    public static void broadcastNewServerIdDueToBetterCapacity(Integer serverPort, String newServerId) {
        byte[] buffer = new byte[1024];
        DatagramSocket socketUDP = null;

        try {
            // Crear el socket UDP
            socketUDP = new DatagramSocket();
            // Enviar solicitud de búsqueda al servidor
            InetAddress broadcastAddress = InetAddress.getByName("25.255.255.255");
            String messageCode = SERVER_TRANSITION_CODE + " " + newServerId;
            buffer = messageCode.getBytes();

            DatagramPacket serverSearchRequest = new DatagramPacket(buffer, buffer.length, broadcastAddress,
                    serverPort);
            System.out.println("Enviando datagrama de id del nuevo servidor...");
            socketUDP.send(serverSearchRequest);

        } catch (IOException e) {
            System.out.println("Ocurrió la excepción IOE");
        } catch (Exception e) {
            System.out.println("Ocurrió una excepción innesperada");
        } finally {
            // Cerrar el socket UDP ya que no será necesario
            if (socketUDP != null && !socketUDP.isClosed()) {
                socketUDP.close();
            }
        }
    }
}
