package Ej.utils;

public class ThreadUtils {
    public static void interruptCurrentThread(Thread thread) {
        if (thread != null && thread.isAlive()) {
            thread.interrupt();
        }
    }
}
