package Ej;

import oshi.SystemInfo;
import oshi.hardware.*;
import oshi.software.os.OperatingSystem;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.*;
import java.net.Socket;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;


public class Client {
    private static final int UPDATE_INTERVAL = 5000; // 5 segundos
    private static final String SERVER_IP = "25.51.170.2";  // IP est�tica del servidor
    private static final int SERVER_PORT = 8080;  // Puerto est�tico

    private static DefaultTableModel tableModel; // Modelo de la tabla
    private static JTable table; // Tabla para mostrar los datos

    public static void main(String[] args) {
        // Crear la ventana de la interfaz gr�fica
        JFrame frame = new JFrame("Cliente");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Definir las columnas de la tabla
        String[] columnNames = {
            "ID", "Modelo Procesador", "Velocidad (GHz)", 
            "Nucleos", "Disco Duro Total (GB)", "SO", "CPU Libre (%)", 
            "Memoria Libre (GB)", "Ancho Banda Libre (%)", "Disco Libre (GB)"
        };
        
        // Crear el modelo de la tabla
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Hacer que las celdas no sean editables
            }
        };
        table = new JTable(tableModel);
        
        // Agregar la tabla a un JScrollPane para hacerla desplazable
        frame.add(new JScrollPane(table));
        frame.setSize(1200, 78); // Tama�o de la ventana
        frame.setLocationRelativeTo(null); // Centrar la ventana en la pantalla
        frame.setVisible(true); // Mostrar la ventana        
        
        try (Scanner scanner = new Scanner(System.in)) {
            // Usamos IP est�tica y puerto est�tico
            String serverIp = SERVER_IP;
            int port = SERVER_PORT;

            // Recuperar el ID guardado o solicitar uno nuevo
            String clientId = getUserId();
            
            
            Socket socket = new Socket(serverIp, port);
            ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());

            // Agregar fila "Calculando..." a la tabla
            Object[] calculatingRow = new Object[columnNames.length];
            for (int i = 0; i < columnNames.length; i++) {
                calculatingRow[i] = "Calculando...";  // Asignar "Calculando..." a todas las columnas
            }
            tableModel.addRow(calculatingRow);            
            
            
            // Hilo para enviar actualizaciones peri�dicas
            Thread updateThread = new Thread(() -> {
                try {
                    while (!Thread.interrupted()) {
                        Map<String, Object> specs = getSystemSpecs(clientId);
                        oos.writeObject(specs);
                        oos.reset(); // Limpiar cache del stream
                        updateTable(specs);
                        Thread.sleep(UPDATE_INTERVAL);
                    }
                } catch (Exception e) {
                    System.out.println("Conexi�n perdida con el servidor.");
                }
            });

            updateThread.start();

            // Esperar entrada del usuario para terminar
            System.out.println("\nPresiona ENTER para desconectarte");
            scanner.nextLine();
            updateThread.interrupt();
            socket.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    private static String getUserId() {
        // Obtener el nombre del usuario actual del sistema
        return System.getProperty("user.name");
    }
    
    private static Map<String, Object> getSystemSpecs(String clientId) {
        SystemInfo si = new SystemInfo();
        HardwareAbstractionLayer hal = si.getHardware();
        CentralProcessor processor = hal.getProcessor();
        GlobalMemory memory = hal.getMemory();
        List<HWDiskStore> diskStores = hal.getDiskStores();
        List<NetworkIF> networks = hal.getNetworkIFs();
        OperatingSystem os = si.getOperatingSystem();

        long[] prevTicks = processor.getSystemCpuLoadTicks();
        try { Thread.sleep(1000); } catch (InterruptedException e) { }
        double cpuFree = 100.0 - (processor.getSystemCpuLoadBetweenTicks(prevTicks) * 100);

        double freeMemory = memory.getAvailable() / (1024.0 * 1024 * 1024);

        double bandwidthFree = 100.0;
        if (!networks.isEmpty()) {
            NetworkIF net = networks.get(0);
            net.updateAttributes();
            long totalBytes = net.getBytesRecv() + net.getBytesSent();
            bandwidthFree = 100.0 - (totalBytes % 100);
        }

        File rootDisk = new File("/");
        double diskFree = rootDisk.getUsableSpace() / (1024.0 * 1024 * 1024);

        Map<String, Object> specs = new HashMap<>();
        specs.put("ID", clientId);
        specs.put("Modelo del Procesador", processor.getProcessorIdentifier().getName());
        specs.put("Velocidad del Procesador (GHz)", processor.getProcessorIdentifier().getVendorFreq() / 1e9);
        specs.put("Nucleos", processor.getLogicalProcessorCount());
        specs.put("Capacidad del Disco Duro (GB)", diskStores.get(0).getSize() / (1024 * 1024 * 1024));
        specs.put("Version del Sistema Operativo", os.toString());
        specs.put("CPU Libre", String.format("%.2f", cpuFree));
        specs.put("Memoria Libre", String.format("%.2f", freeMemory));
        specs.put("Ancho de Banda Libre", String.format("%.2f", bandwidthFree));
        specs.put("Disco Libre", String.format("%.2f", diskFree));

        return specs;
    }
    private static void updateTable(Map<String, Object> specs) {
        // Limpiar los datos actuales en la tabla
        tableModel.setRowCount(0);

        // Crear una fila que coincida con las columnas de la tabla
        Object[] rowData = new Object[10];  // Porque tienes 10 columnas

        // Asignar valores a las columnas espec�ficas seg�n el mapa 'specs'
        rowData[0] = specs.get("ID");  // ID
        rowData[1] = specs.get("Modelo Procesador");  // Modelo Procesador
        rowData[2] = specs.get("Velocidad (GHz)");  // Velocidad (GHz)
        rowData[3] = specs.get("Nucleos");  // Nucleos
        rowData[4] = specs.get("Disco Duro Total (GB)");  // Disco Duro Total (GB)
        rowData[5] = specs.get("SO");  // SO
        rowData[6] = specs.get("CPU Libre (%)");  // CPU Libre (%)
        rowData[7] = specs.get("Memoria Libre (GB)");  // Memoria Libre (GB)
        rowData[8] = specs.get("Ancho Banda Libre (%)");  // Ancho Banda Libre (%)
        rowData[9] = specs.get("Disco Libre (GB)");  // Disco Libre (GB)

        // Agregar la fila a la tabla
        tableModel.addRow(rowData);
    }
}
