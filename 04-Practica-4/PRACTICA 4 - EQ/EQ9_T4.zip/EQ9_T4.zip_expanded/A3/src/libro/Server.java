package libro;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.*;
import java.net.*;

public class Server {
    public static void main(String[] args) {
        int port = 5355; // Puerto de escucha del servidor

        JFrame serverFrame = new JFrame("Servidor");
        serverFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Crear una tabla para mostrar las caracter�sticas
        DefaultTableModel tableModel = new DefaultTableModel();
        JTable table = new JTable(tableModel);
        tableModel.addColumn("Caracter�stica");
        tableModel.addColumn("Valor");

        serverFrame.add(new JScrollPane(table));
        serverFrame.pack();
        serverFrame.setVisible(true);

        // Mostrar las caracter�sticas del servidor al inicio
        String[] serverFeatures = getSystemInfo();
        for (String feature : serverFeatures) {
            String[] parts = feature.split(":");
            addRowToTable(tableModel, parts[0], parts[1]);
        }

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Esperando conexiones en el puerto " + port);

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Cliente conectado desde: " + clientSocket.getInetAddress());

                // Obtener entrada y salida de datos
                ObjectOutputStream outputStream = new ObjectOutputStream(clientSocket.getOutputStream());
                ObjectInputStream inputStream = new ObjectInputStream(clientSocket.getInputStream());

                // Recibir solicitud del cliente para obtener caracter�sticas
                Object request = inputStream.readObject();
                if (request instanceof String && ((String) request).equals("request")) {
                    // Obtener y enviar caracter�sticas del servidor al cliente
                    outputStream.writeObject(serverFeatures);
                }

                // Recibir caracter�sticas del cliente
                Object clientResponse = inputStream.readObject();
                if (clientResponse instanceof String[]) {
                    String[] clientFeatures = (String[]) clientResponse;
                    for (String feature : clientFeatures) {
                        String[] parts = feature.split(":");
                        addRowToTable(tableModel, "Cliente " + parts[0], parts[1]);
                    }
                }

                // Cierra la conexi�n con el cliente
                clientSocket.close();
                System.out.println("Conexi�n cerrada con el cliente.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // M�todo para obtener las caracter�sticas del sistema
    private static String[] getSystemInfo() {
        String[] features = new String[4]; // Tama�o del arreglo ajustado para las nuevas caracter�sticas (sin velocidad del procesador)
        try {
            // Informaci�n del sistema operativo
            String osName = System.getProperty("os.name");
            String osVersion = System.getProperty("os.version");
            features[0] = "Versi�n del sistema operativo: " + osName + " " + osVersion;

            // Informaci�n del hardware
            String processorModel = System.getenv("PROCESSOR_IDENTIFIER");
            String processorCores = System.getenv("NUMBER_OF_PROCESSORS");
            features[1] = "Modelo del procesador: " + processorModel;
            features[2] = "N�mero de n�cleos: " + processorCores;

            // Tama�o del disco duro
            File file = new File("/");
            long totalDiskSpace = file.getTotalSpace();
            features[3] = "Tama�o del disco duro: " + totalDiskSpace + " bytes";

        } catch (Exception e) {
            e.printStackTrace();
        }
        return features;
    }

    // M�todo para agregar una fila a la tabla
    private static void addRowToTable(DefaultTableModel tableModel, String feature, String value) {
        tableModel.addRow(new String[]{feature, value});
    }
}
