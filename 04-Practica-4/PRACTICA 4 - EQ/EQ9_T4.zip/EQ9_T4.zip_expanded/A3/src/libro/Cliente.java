package libro;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.*;
import java.net.*;

public class Cliente {
    public static void main(String[] args) {
        String serverAddress = "25.47.153.25"; // Direcci�n IP del servidor
        int port = 5355; // Puerto del servidor

        // Crear una ventana para mostrar las caracter�sticas del cliente
        JFrame clientFrame = new JFrame("Cliente");
        clientFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Crear una tabla para mostrar las caracter�sticas
        DefaultTableModel tableModel = new DefaultTableModel();
        JTable table = new JTable(tableModel);
        tableModel.addColumn("Caracter�stica");
        tableModel.addColumn("Valor");

        clientFrame.add(new JScrollPane(table));
        clientFrame.pack();
        clientFrame.setVisible(true);

        try {
            Socket socket = new Socket(serverAddress, port);

            // Obtener entrada y salida de datos
            ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());

            // Enviar solicitud al servidor para obtener caracter�sticas
            outputStream.writeObject("request");

            // Obtener y enviar caracter�sticas del cliente al servidor
            String[] clientFeatures = getSystemInfo();
            outputStream.writeObject(clientFeatures);

            // Recibir caracter�sticas del servidor (en este caso, se ignoran)
            Object response = inputStream.readObject();
            if (response instanceof String[]) {
                // No mostrar caracter�sticas del servidor
            }

            // Mostrar caracter�sticas del cliente en la tabla
            for (String feature : clientFeatures) {
                String[] parts = feature.split(":");
                addRowToTable(tableModel, parts[0], parts.length > 1 ? parts[1] : "No disponible");
            }

            // Cierra la conexi�n con el servidor
            socket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // M�todo para agregar una fila a la tabla
    private static void addRowToTable(DefaultTableModel tableModel, String feature, String value) {
        tableModel.addRow(new String[]{feature, value});
    }

    // M�todo para obtener las caracter�sticas del sistema del cliente
    private static String[] getSystemInfo() {
        String[] features = new String[5]; // Ajustar el tama�o del arreglo para incluir el nombre de la m�quina
        try {
            // Informaci�n del sistema operativo
            String osName = System.getProperty("os.name");
            String osVersion = System.getProperty("os.version");
            features[0] = "Nombre de la m�quina: " + System.getProperty("user.name"); // Agregar nombre de la m�quina
            features[1] = "Sistema operativo: " + osName + " " + osVersion;

            // Informaci�n del hardware
            String processorModel = System.getenv("PROCESSOR_IDENTIFIER");
            features[2] = "Modelo del procesador: " + (processorModel != null ? processorModel : "No disponible");

            // Obtener el n�mero de n�cleos
            String processorCores = System.getenv("NUMBER_OF_PROCESSORS");
            features[3] = "N�mero de n�cleos: " + (processorCores != null ? processorCores : "No disponible");

            // Tama�o del disco duro
            File file = new File("/");
            long totalDiskSpace = file.getTotalSpace();
            features[4] = "Tama�o del disco duro: " + totalDiskSpace + " bytes";

        } catch (Exception e) {
            e.printStackTrace();
        }
        return features;
    }
}
